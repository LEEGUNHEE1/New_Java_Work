package com.day18;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Test3 {

	public static void main(String[] args) {
		
		try {
			
			FileOutputStream fos =
					new FileOutputStream("c:\\doc\\data.txt");
			ObjectOutputStream oos =
					new ObjectOutputStream(fos);
						
			oos.writeObject(new MyData("�����", 70));			
			oos.writeObject(new MyData("���γ�", 50));
			oos.writeObject(new MyData("������", 50));
			oos.writeObject(new MyData("���γ�", 30));
			oos.writeObject(new MyData("���ҹ�!", 20));
			
			oos.close();
			fos.close(); //����ȭ ��
			System.out.println("���� ���� �Ϸ�!!");
						
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		//---------------------------------------	
		
		try {
			
			//������ȭ
			
			FileInputStream fis = 
					new FileInputStream("c:\\doc\\data.txt");
			ObjectInputStream ois = 
					new ObjectInputStream(fis);
			
			MyData ob = null;
			
			while(true) {
				
				ob = (MyData)ois.readObject();//downcast
				
				if(ob==null) {
					break;
				}
				
				System.out.println(ob.toString());	
				
			}
			
			ois.close();
			fis.close();
					
		} catch (Exception e) {
			//System.out.println("������ �������Դϴ�");
		}

	}

}
